﻿
namespace Exercice2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clavier1 = new Exercice2.Clavier();
            this.clavier2 = new Exercice2.Clavier();
            this.clavier3 = new Exercice2.Clavier();
            this.clavier4 = new Exercice2.Clavier();
            this.clavier5 = new Exercice2.Clavier();
            this.clavier6 = new Exercice2.Clavier();
            this.clavier7 = new Exercice2.Clavier();
            this.clavier8 = new Exercice2.Clavier();
            this.clavier9 = new Exercice2.Clavier();
            this.clavier10 = new Exercice2.Clavier();
            this.clavier11 = new Exercice2.Clavier();
            this.clavier12 = new Exercice2.Clavier();
            this.clavier13 = new Exercice2.Clavier();
            this.clavier14 = new Exercice2.Clavier();
            this.clavier15 = new Exercice2.Clavier();
            this.clavier16 = new Exercice2.Clavier();
            this.clavier17 = new Exercice2.Clavier();
            this.clavier18 = new Exercice2.Clavier();
            this.clavier19 = new Exercice2.Clavier();
            this.clavier20 = new Exercice2.Clavier();
            this.clavier21 = new Exercice2.Clavier();
            this.clavier22 = new Exercice2.Clavier();
            this.clavier23 = new Exercice2.Clavier();
            this.clavier24 = new Exercice2.Clavier();
            this.clavier25 = new Exercice2.Clavier();
            this.clavier26 = new Exercice2.Clavier();
            this.tbxText = new System.Windows.Forms.TextBox();
            this.tbxReverse = new System.Windows.Forms.TextBox();
            this.btnReverse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // clavier1
            // 
            this.clavier1.BackColor = System.Drawing.Color.Black;
            this.clavier1.ForeColor = System.Drawing.Color.White;
            this.clavier1.Lettre = null;
            this.clavier1.Location = new System.Drawing.Point(532, 277);
            this.clavier1.Name = "clavier1";
            this.clavier1.Size = new System.Drawing.Size(50, 50);
            this.clavier1.TabIndex = 27;
            this.clavier1.Text = "M";
            this.clavier1.UseVisualStyleBackColor = false;
            // 
            // clavier2
            // 
            this.clavier2.BackColor = System.Drawing.Color.Black;
            this.clavier2.ForeColor = System.Drawing.Color.White;
            this.clavier2.Lettre = "";
            this.clavier2.Location = new System.Drawing.Point(477, 277);
            this.clavier2.Name = "clavier2";
            this.clavier2.Size = new System.Drawing.Size(50, 50);
            this.clavier2.TabIndex = 28;
            this.clavier2.Text = "N";
            this.clavier2.UseVisualStyleBackColor = false;
            // 
            // clavier3
            // 
            this.clavier3.BackColor = System.Drawing.Color.Black;
            this.clavier3.ForeColor = System.Drawing.Color.White;
            this.clavier3.Lettre = "";
            this.clavier3.Location = new System.Drawing.Point(422, 277);
            this.clavier3.Name = "clavier3";
            this.clavier3.Size = new System.Drawing.Size(50, 50);
            this.clavier3.TabIndex = 29;
            this.clavier3.Text = "B";
            this.clavier3.UseVisualStyleBackColor = false;
            // 
            // clavier4
            // 
            this.clavier4.BackColor = System.Drawing.Color.Black;
            this.clavier4.ForeColor = System.Drawing.Color.White;
            this.clavier4.Lettre = "";
            this.clavier4.Location = new System.Drawing.Point(367, 277);
            this.clavier4.Name = "clavier4";
            this.clavier4.Size = new System.Drawing.Size(50, 50);
            this.clavier4.TabIndex = 30;
            this.clavier4.Text = "V";
            this.clavier4.UseVisualStyleBackColor = false;
            // 
            // clavier5
            // 
            this.clavier5.BackColor = System.Drawing.Color.Black;
            this.clavier5.ForeColor = System.Drawing.Color.White;
            this.clavier5.Lettre = "";
            this.clavier5.Location = new System.Drawing.Point(312, 277);
            this.clavier5.Name = "clavier5";
            this.clavier5.Size = new System.Drawing.Size(50, 50);
            this.clavier5.TabIndex = 31;
            this.clavier5.Text = "C";
            this.clavier5.UseVisualStyleBackColor = false;
            // 
            // clavier6
            // 
            this.clavier6.BackColor = System.Drawing.Color.Black;
            this.clavier6.ForeColor = System.Drawing.Color.White;
            this.clavier6.Lettre = "";
            this.clavier6.Location = new System.Drawing.Point(257, 277);
            this.clavier6.Name = "clavier6";
            this.clavier6.Size = new System.Drawing.Size(50, 50);
            this.clavier6.TabIndex = 32;
            this.clavier6.Text = "X";
            this.clavier6.UseVisualStyleBackColor = false;
            // 
            // clavier7
            // 
            this.clavier7.BackColor = System.Drawing.Color.Black;
            this.clavier7.ForeColor = System.Drawing.Color.White;
            this.clavier7.Lettre = "";
            this.clavier7.Location = new System.Drawing.Point(202, 277);
            this.clavier7.Name = "clavier7";
            this.clavier7.Size = new System.Drawing.Size(50, 50);
            this.clavier7.TabIndex = 33;
            this.clavier7.Text = "Y";
            this.clavier7.UseVisualStyleBackColor = false;
            // 
            // clavier8
            // 
            this.clavier8.BackColor = System.Drawing.Color.Black;
            this.clavier8.ForeColor = System.Drawing.Color.White;
            this.clavier8.Lettre = "";
            this.clavier8.Location = new System.Drawing.Point(609, 221);
            this.clavier8.Name = "clavier8";
            this.clavier8.Size = new System.Drawing.Size(50, 50);
            this.clavier8.TabIndex = 34;
            this.clavier8.Text = "L";
            this.clavier8.UseVisualStyleBackColor = false;
            // 
            // clavier9
            // 
            this.clavier9.BackColor = System.Drawing.Color.Black;
            this.clavier9.ForeColor = System.Drawing.Color.White;
            this.clavier9.Lettre = "";
            this.clavier9.Location = new System.Drawing.Point(554, 221);
            this.clavier9.Name = "clavier9";
            this.clavier9.Size = new System.Drawing.Size(50, 50);
            this.clavier9.TabIndex = 35;
            this.clavier9.Text = "K";
            this.clavier9.UseVisualStyleBackColor = false;
            // 
            // clavier10
            // 
            this.clavier10.BackColor = System.Drawing.Color.Black;
            this.clavier10.ForeColor = System.Drawing.Color.White;
            this.clavier10.Lettre = "";
            this.clavier10.Location = new System.Drawing.Point(499, 221);
            this.clavier10.Name = "clavier10";
            this.clavier10.Size = new System.Drawing.Size(50, 50);
            this.clavier10.TabIndex = 36;
            this.clavier10.Text = "J";
            this.clavier10.UseVisualStyleBackColor = false;
            // 
            // clavier11
            // 
            this.clavier11.BackColor = System.Drawing.Color.Black;
            this.clavier11.ForeColor = System.Drawing.Color.White;
            this.clavier11.Lettre = "";
            this.clavier11.Location = new System.Drawing.Point(444, 221);
            this.clavier11.Name = "clavier11";
            this.clavier11.Size = new System.Drawing.Size(50, 50);
            this.clavier11.TabIndex = 37;
            this.clavier11.Text = "H";
            this.clavier11.UseVisualStyleBackColor = false;
            // 
            // clavier12
            // 
            this.clavier12.BackColor = System.Drawing.Color.Black;
            this.clavier12.ForeColor = System.Drawing.Color.White;
            this.clavier12.Lettre = "";
            this.clavier12.Location = new System.Drawing.Point(389, 221);
            this.clavier12.Name = "clavier12";
            this.clavier12.Size = new System.Drawing.Size(50, 50);
            this.clavier12.TabIndex = 38;
            this.clavier12.Text = "G";
            this.clavier12.UseVisualStyleBackColor = false;
            // 
            // clavier13
            // 
            this.clavier13.BackColor = System.Drawing.Color.Black;
            this.clavier13.ForeColor = System.Drawing.Color.White;
            this.clavier13.Lettre = "";
            this.clavier13.Location = new System.Drawing.Point(334, 221);
            this.clavier13.Name = "clavier13";
            this.clavier13.Size = new System.Drawing.Size(50, 50);
            this.clavier13.TabIndex = 39;
            this.clavier13.Text = "F";
            this.clavier13.UseVisualStyleBackColor = false;
            // 
            // clavier14
            // 
            this.clavier14.BackColor = System.Drawing.Color.Black;
            this.clavier14.ForeColor = System.Drawing.Color.White;
            this.clavier14.Lettre = "";
            this.clavier14.Location = new System.Drawing.Point(279, 221);
            this.clavier14.Name = "clavier14";
            this.clavier14.Size = new System.Drawing.Size(50, 50);
            this.clavier14.TabIndex = 40;
            this.clavier14.Text = "D";
            this.clavier14.UseVisualStyleBackColor = false;
            // 
            // clavier15
            // 
            this.clavier15.BackColor = System.Drawing.Color.Black;
            this.clavier15.ForeColor = System.Drawing.Color.White;
            this.clavier15.Lettre = "";
            this.clavier15.Location = new System.Drawing.Point(224, 221);
            this.clavier15.Name = "clavier15";
            this.clavier15.Size = new System.Drawing.Size(50, 50);
            this.clavier15.TabIndex = 41;
            this.clavier15.Text = "S";
            this.clavier15.UseVisualStyleBackColor = false;
            // 
            // clavier16
            // 
            this.clavier16.BackColor = System.Drawing.Color.Black;
            this.clavier16.ForeColor = System.Drawing.Color.White;
            this.clavier16.Lettre = "";
            this.clavier16.Location = new System.Drawing.Point(169, 221);
            this.clavier16.Name = "clavier16";
            this.clavier16.Size = new System.Drawing.Size(50, 50);
            this.clavier16.TabIndex = 42;
            this.clavier16.Text = "A";
            this.clavier16.UseVisualStyleBackColor = false;
            // 
            // clavier17
            // 
            this.clavier17.BackColor = System.Drawing.Color.Black;
            this.clavier17.ForeColor = System.Drawing.Color.White;
            this.clavier17.Lettre = "";
            this.clavier17.Location = new System.Drawing.Point(147, 165);
            this.clavier17.Name = "clavier17";
            this.clavier17.Size = new System.Drawing.Size(50, 50);
            this.clavier17.TabIndex = 43;
            this.clavier17.Text = "Q";
            this.clavier17.UseVisualStyleBackColor = false;
            // 
            // clavier18
            // 
            this.clavier18.BackColor = System.Drawing.Color.Black;
            this.clavier18.ForeColor = System.Drawing.Color.White;
            this.clavier18.Lettre = "";
            this.clavier18.Location = new System.Drawing.Point(202, 165);
            this.clavier18.Name = "clavier18";
            this.clavier18.Size = new System.Drawing.Size(50, 50);
            this.clavier18.TabIndex = 44;
            this.clavier18.Text = "W";
            this.clavier18.UseVisualStyleBackColor = false;
            // 
            // clavier19
            // 
            this.clavier19.BackColor = System.Drawing.Color.Black;
            this.clavier19.ForeColor = System.Drawing.Color.White;
            this.clavier19.Lettre = "";
            this.clavier19.Location = new System.Drawing.Point(256, 165);
            this.clavier19.Name = "clavier19";
            this.clavier19.Size = new System.Drawing.Size(50, 50);
            this.clavier19.TabIndex = 45;
            this.clavier19.Text = "E";
            this.clavier19.UseVisualStyleBackColor = false;
            // 
            // clavier20
            // 
            this.clavier20.BackColor = System.Drawing.Color.Black;
            this.clavier20.ForeColor = System.Drawing.Color.White;
            this.clavier20.Lettre = "";
            this.clavier20.Location = new System.Drawing.Point(312, 165);
            this.clavier20.Name = "clavier20";
            this.clavier20.Size = new System.Drawing.Size(50, 50);
            this.clavier20.TabIndex = 46;
            this.clavier20.Text = "R";
            this.clavier20.UseVisualStyleBackColor = false;
            // 
            // clavier21
            // 
            this.clavier21.BackColor = System.Drawing.Color.Black;
            this.clavier21.ForeColor = System.Drawing.Color.White;
            this.clavier21.Lettre = "";
            this.clavier21.Location = new System.Drawing.Point(367, 165);
            this.clavier21.Name = "clavier21";
            this.clavier21.Size = new System.Drawing.Size(50, 50);
            this.clavier21.TabIndex = 47;
            this.clavier21.Text = "T";
            this.clavier21.UseVisualStyleBackColor = false;
            // 
            // clavier22
            // 
            this.clavier22.BackColor = System.Drawing.Color.Black;
            this.clavier22.ForeColor = System.Drawing.Color.White;
            this.clavier22.Lettre = "";
            this.clavier22.Location = new System.Drawing.Point(422, 165);
            this.clavier22.Name = "clavier22";
            this.clavier22.Size = new System.Drawing.Size(50, 50);
            this.clavier22.TabIndex = 48;
            this.clavier22.Text = "Z";
            this.clavier22.UseVisualStyleBackColor = false;
            // 
            // clavier23
            // 
            this.clavier23.BackColor = System.Drawing.Color.Black;
            this.clavier23.ForeColor = System.Drawing.Color.White;
            this.clavier23.Lettre = "";
            this.clavier23.Location = new System.Drawing.Point(477, 165);
            this.clavier23.Name = "clavier23";
            this.clavier23.Size = new System.Drawing.Size(50, 50);
            this.clavier23.TabIndex = 49;
            this.clavier23.Text = "U";
            this.clavier23.UseVisualStyleBackColor = false;
            // 
            // clavier24
            // 
            this.clavier24.BackColor = System.Drawing.Color.Black;
            this.clavier24.ForeColor = System.Drawing.Color.White;
            this.clavier24.Lettre = "";
            this.clavier24.Location = new System.Drawing.Point(532, 165);
            this.clavier24.Name = "clavier24";
            this.clavier24.Size = new System.Drawing.Size(50, 50);
            this.clavier24.TabIndex = 50;
            this.clavier24.Text = "I";
            this.clavier24.UseVisualStyleBackColor = false;
            // 
            // clavier25
            // 
            this.clavier25.BackColor = System.Drawing.Color.Black;
            this.clavier25.ForeColor = System.Drawing.Color.White;
            this.clavier25.Lettre = "";
            this.clavier25.Location = new System.Drawing.Point(587, 165);
            this.clavier25.Name = "clavier25";
            this.clavier25.Size = new System.Drawing.Size(50, 50);
            this.clavier25.TabIndex = 51;
            this.clavier25.Text = "O";
            this.clavier25.UseVisualStyleBackColor = false;
            // 
            // clavier26
            // 
            this.clavier26.BackColor = System.Drawing.Color.Black;
            this.clavier26.ForeColor = System.Drawing.Color.White;
            this.clavier26.Lettre = "";
            this.clavier26.Location = new System.Drawing.Point(642, 165);
            this.clavier26.Name = "clavier26";
            this.clavier26.Size = new System.Drawing.Size(50, 50);
            this.clavier26.TabIndex = 52;
            this.clavier26.Text = "P";
            this.clavier26.UseVisualStyleBackColor = false;
            // 
            // tbxText
            // 
            this.tbxText.Location = new System.Drawing.Point(12, 12);
            this.tbxText.Name = "tbxText";
            this.tbxText.ReadOnly = true;
            this.tbxText.Size = new System.Drawing.Size(780, 23);
            this.tbxText.TabIndex = 0;
            // 
            // tbxReverse
            // 
            this.tbxReverse.Location = new System.Drawing.Point(12, 102);
            this.tbxReverse.Name = "tbxReverse";
            this.tbxReverse.ReadOnly = true;
            this.tbxReverse.Size = new System.Drawing.Size(780, 23);
            this.tbxReverse.TabIndex = 53;
            // 
            // btnReverse
            // 
            this.btnReverse.Location = new System.Drawing.Point(364, 53);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(75, 23);
            this.btnReverse.TabIndex = 54;
            this.btnReverse.Text = "Reverse";
            this.btnReverse.UseVisualStyleBackColor = true;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.tbxReverse);
            this.Controls.Add(this.clavier26);
            this.Controls.Add(this.clavier25);
            this.Controls.Add(this.clavier24);
            this.Controls.Add(this.clavier23);
            this.Controls.Add(this.clavier22);
            this.Controls.Add(this.clavier21);
            this.Controls.Add(this.clavier20);
            this.Controls.Add(this.clavier19);
            this.Controls.Add(this.clavier18);
            this.Controls.Add(this.clavier17);
            this.Controls.Add(this.clavier16);
            this.Controls.Add(this.clavier15);
            this.Controls.Add(this.clavier14);
            this.Controls.Add(this.clavier13);
            this.Controls.Add(this.clavier12);
            this.Controls.Add(this.clavier11);
            this.Controls.Add(this.clavier10);
            this.Controls.Add(this.clavier9);
            this.Controls.Add(this.clavier8);
            this.Controls.Add(this.clavier7);
            this.Controls.Add(this.clavier6);
            this.Controls.Add(this.clavier5);
            this.Controls.Add(this.clavier4);
            this.Controls.Add(this.clavier3);
            this.Controls.Add(this.clavier2);
            this.Controls.Add(this.clavier1);
            this.Controls.Add(this.tbxText);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxText;
        private Clavier clavier1;
        private Clavier clavier2;
        private Clavier clavier3;
        private Clavier clavier4;
        private Clavier clavier5;
        private Clavier clavier6;
        private Clavier clavier7;
        private Clavier clavier8;
        private Clavier clavier9;
        private Clavier clavier10;
        private Clavier clavier11;
        private Clavier clavier12;
        private Clavier clavier13;
        private Clavier clavier14;
        private Clavier clavier15;
        private Clavier clavier16;
        private Clavier clavier17;
        private Clavier clavier18;
        private Clavier clavier19;
        private Clavier clavier20;
        private Clavier clavier21;
        private Clavier clavier22;
        private Clavier clavier23;
        private Clavier clavier24;
        private Clavier clavier25;
        private Clavier clavier26;
        private System.Windows.Forms.TextBox tbxReverse;
        private System.Windows.Forms.Button btnReverse;
    }
}

