﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueueCinemaObjet
{
    class Personne
    {
        //Champs
        private string _prenom;
        private int _numeroGroup = 0;
        


        //Propriétés
        public string Prenom
        {
            get { return _prenom; }
            set { _prenom = value; }
        }

        public int NumeroGroup
        {
            get { return _numeroGroup; }
            set { _numeroGroup = value; }
        }
        
        //Constructeur
        public Personne(string prenom, int numeroGroup)
        {
            _prenom = prenom;
            _numeroGroup = numeroGroup;
        }

        public override string ToString()
        {
            return _prenom + "(" + _numeroGroup + ")  ";
        }
    }
}
